# Gökbörü Browser — Reklam Engelleme (Android)

Bu proje, Gökbörü'nün koyu lacivert ve altın renkli tasarımını koruyan, Android WebView tabanlı bir başlangıç tarayıcısı ve yerleşik reklam/izleyici engelleme prototipidir.

## GitHub üzerinden APK oluşturma
1. ZIP dosyasını çıkarın.
2. İçindeki dosyaları bir GitHub deposunun kök dizinine yükleyin (özellikle `settings.gradle.kts`, `build.gradle.kts`, `app/` ve `.github/`).
3. GitHub'da **Actions** sekmesine girin.
4. **Gokboru Android APK** iş akışını açıp **Run workflow** seçin.
5. İş bitince `gokboru-adblock-apk` adlı artifact'i indirin. İçindeki `app-debug.apk` Android cihazda kurulabilir.

## Reklam engelleyici nasıl çalışır?
- Başlangıçta yerleşik alan adı engel listesi kullanılır.
- İnternet erişimi olduğunda EasyList ve EasyPrivacy listelerini indirmeyi dener.
- WebView alt kaynak isteklerini filtreler ve engellenen istek sayacını gösterir.
- Ayardaki anahtarla engellemeyi açıp kapatabilirsiniz.

## Önemli sınırlamalar
- Bu, tam bir Opera/uBlock Origin filtre motoru değildir. EasyList/EasyPrivacy biçimlerinin yalnızca bir kısmı yorumlanır; gelişmiş istisnalar, kozmetik filtreler ve tüm ABP kuralları desteklenmez.
- Android WebView'in API kısıtlamaları nedeniyle reklam engelleme her sitede ve her reklam türünde garanti değildir. YouTube gibi sitelerde tüm reklamlar engellenmeyebilir.
- İlk sürümde sekme düğmesi yeni WebView sekmesi değil, yeni Google sayfası açar. Çoklu sekme ve gizli sekme daha sonra ayrı WebView örnekleriyle tamamlanmalıdır.
- Filtre listeleri uzaktan indirilir; uygulamanın internet izni gerekir.
- APK bu kaynak ZIP'inin içinde önceden derlenmiş olarak bulunmaz. GitHub Actions derlemesiyle oluşturulur.

## Teknik bilgiler
- Kotlin, Android SDK 35, minSdk 23
- Java 17, Gradle 8.9
- Paket: `com.gokboru.browser`
