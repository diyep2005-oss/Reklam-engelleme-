# Gökbörü Browser ProGuard rules
