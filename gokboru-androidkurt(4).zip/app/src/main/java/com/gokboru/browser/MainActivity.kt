package com.gokboru.browser

import android.annotation.SuppressLint
import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.webkit.*
import android.widget.*
import android.content.Context
import android.content.SharedPreferences
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

class MainActivity : Activity() {
    private lateinit var web: WebView
    private lateinit var address: EditText
    private lateinit var prefs: SharedPreferences
    private lateinit var blocker: AdBlockEngine
    private lateinit var countLabel: TextView
    private val executor = Executors.newSingleThreadExecutor()
    private val gold = Color.rgb(244, 183, 76)
    private val navy = Color.rgb(5, 17, 30)
    private val panel = Color.rgb(18, 35, 53)

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        prefs = getSharedPreferences("gokboru", Context.MODE_PRIVATE)
        blocker = AdBlockEngine(this)
        buildUi()
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.settings.loadsImagesAutomatically = true
        web.settings.javaScriptCanOpenWindowsAutomatically = false
        web.settings.setSupportMultipleWindows(false)
        web.settings.mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val url = request?.url?.toString() ?: return false
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    address.setText(url)
                    return false
                }
                return true
            }

            override fun shouldInterceptRequest(view: WebView?, request: WebResourceRequest?): WebResourceResponse? {
                val url = request?.url?.toString() ?: return null
                if (prefs.getBoolean("adblock_enabled", true) && blocker.shouldBlock(url, request.isForMainFrame)) {
                    blocker.blocked.incrementAndGet()
                    runOnUiThread { countLabel.text = "Engellenen: ${blocker.blocked.get()}" }
                    return WebResourceResponse("text/plain", "utf-8", 204, "No Content",
                        mapOf("Access-Control-Allow-Origin" to "*"), java.io.ByteArrayInputStream(ByteArray(0)))
                }
                return null
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: android.graphics.Bitmap?) {
                address.setText(url ?: "")
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                address.setText(url ?: "")
            }
        }
        web.webChromeClient = WebChromeClient()
        if (savedInstanceState != null) web.restoreState(savedInstanceState)
        else web.loadUrl("https://www.google.com")
        executor.execute { blocker.updateFilters() }
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(navy)
        }
        val brand = TextView(this).apply {
            text = "✦  GÖKBÖRÜ BROWSER"
            setTextColor(gold); textSize = 19f; typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER_VERTICAL; setPadding(16, 12, 12, 8)
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 48))
        val bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 4, 8, 8)
        }
        address = EditText(this).apply {
            hint = "Arama yap veya adres gir"; singleLine = true
            setTextColor(Color.WHITE); setHintTextColor(0xff9eafc1.toInt())
            textSize = 14f; setPadding(14, 0, 12, 0)
            setBackgroundColor(panel); imeOptions = EditorInfo.IME_ACTION_GO
            setOnEditorActionListener { _, action, _ ->
                if (action == EditorInfo.IME_ACTION_GO || action == EditorInfo.IME_ACTION_DONE) {
                    navigate(text.toString()); true
                } else false
            }
        }
        bar.addView(address, LinearLayout.LayoutParams(0, 46, 1f))
        val go = Button(this).apply {
            text = "Git"; setTextColor(navy); setBackgroundTintList(android.content.res.ColorStateList.valueOf(gold))
            setOnClickListener { navigate(address.text.toString()) }
        }
        bar.addView(go, LinearLayout.LayoutParams(-2, 46))
        root.addView(bar)
        val controls = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(8, 0, 8, 6)
        }
        fun smallButton(label: String, action: () -> Unit): Button = Button(this).apply {
            text = label; textSize = 12f; setTextColor(Color.WHITE)
            setBackgroundTintList(android.content.res.ColorStateList.valueOf(panel))
            setOnClickListener { action() }
        }
        controls.addView(smallButton("‹") { if (web.canGoBack()) web.goBack() }, LinearLayout.LayoutParams(48, 42))
        controls.addView(smallButton("›") { if (web.canGoForward()) web.goForward() }, LinearLayout.LayoutParams(48, 42))
        controls.addView(smallButton("Ana sayfa") { web.loadUrl("https://www.google.com") }, LinearLayout.LayoutParams(0, 42, 1f))
        controls.addView(smallButton("Sekme +") { web.loadUrl("https://www.google.com") }, LinearLayout.LayoutParams(-2, 42))
        root.addView(controls)
        val status = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            setPadding(12, 2, 12, 6)
        }
        countLabel = TextView(this).apply {
            text = "Engellenen: 0"; setTextColor(gold); textSize = 12f
        }
        status.addView(countLabel, LinearLayout.LayoutParams(0, 30, 1f))
        val toggle = Switch(this).apply {
            text = "Reklam engelleme"; setTextColor(Color.WHITE)
            isChecked = prefs.getBoolean("adblock_enabled", true)
            setOnCheckedChangeListener { _, checked ->
                prefs.edit().putBoolean("adblock_enabled", checked).apply()
                text = if (checked) "Reklam engelleme" else "Engelleme kapalı"
            }
        }
        status.addView(toggle)
        root.addView(status)
        web = WebView(this).apply { setBackgroundColor(Color.WHITE) }
        root.addView(web, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun navigate(raw: String) {
        val input = raw.trim()
        if (input.isEmpty()) return
        val target = when {
            input.startsWith("https://") || input.startsWith("http://") -> input
            input.contains(" ") || !input.contains(".") -> "https://www.google.com/search?q=" + android.net.Uri.encode(input)
            else -> "https://$input"
        }
        web.loadUrl(target)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        web.saveState(outState)
        super.onSaveInstanceState(outState)
    }
    override fun onBackPressed() {
        if (::web.isInitialized && web.canGoBack()) web.goBack() else super.onBackPressed()
    }
    override fun onDestroy() {
        if (::web.isInitialized) web.destroy()
        executor.shutdownNow()
        super.onDestroy()
    }
}

/**
 * Lightweight WebView request blocker. Supports host lists and common ABP-style
 * network rules. This is not a full uBlock/Opera filter engine.
 */
class AdBlockEngine(private val context: Context) {
    val blocked = AtomicInteger(0)
    @Volatile private var exactHosts: Set<String> = defaultHosts
    @Volatile private var rules: List<String> = emptyList()
    private val prefs = context.getSharedPreferences("gokboru", Context.MODE_PRIVATE)

    fun shouldBlock(rawUrl: String, isMainFrame: Boolean): Boolean {
        val uri = try { android.net.Uri.parse(rawUrl) } catch (_: Exception) { return false }
        val host = (uri.host ?: return false).lowercase()
        if (host in exactHosts || exactHosts.any { host.endsWith(".$it") }) return true
        val path = (uri.encodedPath ?: "") + (uri.encodedQuery?.let { "?$it" } ?: "")
        for (line in rules) {
            if (!line.contains("##") && !line.startsWith("!") && !line.startsWith("[") &&
                !line.startsWith("@@") && line.contains("://")) {
                val pattern = line.removePrefix("||").substringBefore("^").substringBefore("/")
                if (pattern.contains('.') && host == pattern) return true
            }
            if (line.startsWith("||") && line.endsWith("^")) {
                val domain = line.removePrefix("||").removeSuffix("^").lowercase()
                if (host == domain || host.endsWith(".$domain")) return true
            }
            if (line.startsWith("/") && line.endsWith("/") && line.length > 2) {
                try { if (Regex(line.substring(1, line.length - 1)).containsMatchIn(rawUrl)) return true } catch (_: Exception) {}
            }
            if (line.contains("\$") && line.contains("script")) {
                val domain = line.substringAfter("||", "").substringBefore("^")
                if (domain.isNotBlank() && host.contains(domain) && path.contains("js")) return true
            }
        }
        return false
    }

    fun updateFilters() {
        val urls = listOf(
            "https://easylist.to/easylist/easylist.txt",
            "https://easylist.to/easylist/easyprivacy.txt"
        )
        val all = mutableListOf<String>()
        for (url in urls) {
            try {
                val conn = URL(url).openConnection() as HttpURLConnection
                conn.connectTimeout = 8000; conn.readTimeout = 12000
                conn.setRequestProperty("User-Agent", "GokboruBrowser/1.1")
                conn.inputStream.bufferedReader().useLines { seq ->
                    seq.filter { it.length in 4..500 && !it.startsWith("!") && !it.startsWith("[") }
                        .take(120000).forEach { all.add(it.trim()) }
                }
                conn.disconnect()
            } catch (_: Exception) { }
        }
        if (all.isNotEmpty()) {
            rules = all
            prefs.edit().putLong("filters_updated", System.currentTimeMillis()).apply()
        }
    }

    companion object {
        private val defaultHosts = setOf(
            "doubleclick.net", "googlesyndication.com", "googleadservices.com",
            "adservice.google.com", "adnxs.com", "ads.yahoo.com", "taboola.com",
            "outbrain.com", "scorecardresearch.com", "adform.net", "criteo.com",
            "zedo.com", "popads.net", "popcash.net", "trackersimulator.org"
        )
    }
}
