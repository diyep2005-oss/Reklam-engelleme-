package com.gokboru.browser

import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.Context
import android.content.ActivityNotFoundException
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.print.PrintAttributes
import android.print.PrintManager
import android.speech.RecognizerIntent
import android.view.MotionEvent
import android.view.WindowManager
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.webkit.CookieManager
import android.webkit.URLUtil
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebStorage
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import android.widget.Toast
import android.app.Dialog
import android.content.ContentValues
import android.content.res.ColorStateList
import android.graphics.Canvas
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.text.InputType
import android.view.Gravity
import android.widget.PopupMenu
import androidx.core.widget.doAfterTextChanged
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import java.io.File
import org.json.JSONArray
import org.json.JSONObject
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat
import androidx.core.content.pm.ShortcutInfoCompat
import androidx.core.content.pm.ShortcutManagerCompat
import androidx.core.graphics.drawable.IconCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import org.json.JSONTokener

/** Tek bir sekme: kendi WebView'i ve son bilinen durumu. */
internal class BrowserTab(val webView: WebView, val isPrivate: Boolean = false) {
    var title: String = ""
    var url: String = ""
    var progress: Int = 100
    var loading: Boolean = false
    var favicon: Bitmap? = null
    var thumb: Bitmap? = null
}

class MainActivity : AppCompatActivity() {

    private companion object {
        const val NEWTAB_URL = "file:///android_asset/newtab.html"
        const val DESKTOP_UA =
            "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) " +
                "Chrome/124.0.0.0 Safari/537.36"
        const val HOME_SCHEME = "gokboru"
        const val APP_VERSION = "1.3.0"
    }

    private lateinit var prefs: Prefs
    private val tabs = mutableListOf<BrowserTab>()
    private var current: BrowserTab? = null
    private var desktopMode = false
    private var lastBackPress = 0L
    private var focusLevel = 0
    private lateinit var swipeRefresh: SwipeRefreshLayout

    private lateinit var topBar: View
    private lateinit var bottomBar: View
    private lateinit var addressBar: EditText
    private lateinit var addressIcon: ImageView
    private lateinit var progressBar: ProgressBar
    private lateinit var webContainer: FrameLayout
    private lateinit var fullscreenContainer: FrameLayout
    private lateinit var btnBack: ImageButton
    private lateinit var btnForward: ImageButton
    private lateinit var btnReload: ImageButton
    private lateinit var tabCount: TextView

    private var gestureStartX = 0f
    private var gestureStartY = 0f
    private var gestureOnBar = false

    private var customView: View? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var fileCallback: ValueCallback<Array<Uri>>? = null

    private val mobileUserAgent: String by lazy {
        // "; wv" ifadesini kaldırmak, birçok sitenin tarayıcıyı normal Chrome gibi görmesini sağlar.
        WebSettings.getDefaultUserAgent(this).replace("; wv", "")
    }

    private val fileChooser =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            fileCallback?.onReceiveValue(uris)
            fileCallback = null
        }

    private val voiceLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            val spoken = result.data
                ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
                ?.firstOrNull()
            if (!spoken.isNullOrBlank()) loadFromInput(spoken)
        }

    // ---------------------------------------------------------------------------------------
    // Yaşam döngüsü
    // ---------------------------------------------------------------------------------------

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = Prefs(this)
        desktopMode = prefs.desktopDefault
        applyKeepScreen()

        topBar = findViewById(R.id.topBar)
        bottomBar = findViewById(R.id.bottomBar)
        addressBar = findViewById(R.id.addressBar)
        addressIcon = findViewById(R.id.addressIcon)
        progressBar = findViewById(R.id.progressBar)
        webContainer = findViewById(R.id.webContainer)
        fullscreenContainer = findViewById(R.id.fullscreenContainer)
        btnBack = findViewById(R.id.btnBack)
        btnForward = findViewById(R.id.btnForward)
        btnReload = findViewById(R.id.btnReload)
        tabCount = findViewById(R.id.tabCount)
        swipeRefresh = findViewById(R.id.swipeRefresh)
        swipeRefresh.setColorSchemeColors(getColor(R.color.gold))
        swipeRefresh.setProgressBackgroundColorSchemeColor(getColor(R.color.surface))
        swipeRefresh.setOnChildScrollUpCallback { _, _ -> (current?.webView?.scrollY ?: 0) > 0 }
        swipeRefresh.setOnRefreshListener {
            current?.webView?.reload()
            swipeRefresh.isRefreshing = false
        }
        addressIcon.setOnClickListener { showSiteInfo() }

        setupAddressBar()
        setupButtons()

        onBackPressedDispatcher.addCallback(
            this,
            object : OnBackPressedCallback(true) {
                override fun handleOnBackPressed() {
                    handleBack()
                }
            }
        )

        val startUrl = intent?.dataString
        newTab(startUrl ?: NEWTAB_URL)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        val url = intent.dataString
        if (url != null) newTab(url)
    }

    override fun onResume() {
        super.onResume()
        current?.webView?.onResume()
    }

    override fun onPause() {
        current?.webView?.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        for (tab in tabs) {
            webContainer.removeView(tab.webView)
            tab.webView.destroy()
        }
        tabs.clear()
        super.onDestroy()
    }

    // ---------------------------------------------------------------------------------------
    // Arayüz kurulumu
    // ---------------------------------------------------------------------------------------

    private fun setupAddressBar() {
        addressBar.setOnFocusChangeListener { view, hasFocus ->
            if (!hasFocus) {
                hideKeyboard(view)
                updateUi()
            }
        }
        addressBar.setOnEditorActionListener { _, actionId, event ->
            val enterPressed = event != null &&
                event.keyCode == KeyEvent.KEYCODE_ENTER &&
                event.action == KeyEvent.ACTION_DOWN
            if (actionId == EditorInfo.IME_ACTION_GO || enterPressed) {
                loadFromInput(addressBar.text.toString())
                addressBar.clearFocus()
                current?.webView?.requestFocus()
                true
            } else {
                false
            }
        }
    }

    private fun setupButtons() {
        btnBack.setOnClickListener {
            val webView = current?.webView
            if (webView != null && webView.canGoBack()) webView.goBack()
        }
        btnForward.setOnClickListener {
            val webView = current?.webView
            if (webView != null && webView.canGoForward()) webView.goForward()
        }
        findViewById<ImageButton>(R.id.btnHome).setOnClickListener {
            current?.webView?.loadUrl(NEWTAB_URL)
        }
        btnReload.setOnClickListener {
            val tab = current
            if (tab != null) {
                if (tab.loading) {
                    tab.webView.stopLoading()
                    tab.loading = false
                    updateUi()
                    updateProgress()
                } else {
                    tab.webView.reload()
                }
            }
        }
        findViewById<ImageButton>(R.id.btnTabs).setOnClickListener { showTabs() }
        findViewById<ImageButton>(R.id.btnMenu).setOnClickListener { showMenu() }
        findViewById<ImageButton>(R.id.btnMic).setOnClickListener { startVoiceSearch() }
    }

    // ---------------------------------------------------------------------------------------
    // Sekme yönetimi
    // ---------------------------------------------------------------------------------------

    @SuppressLint("SetJavaScriptEnabled")
    private fun newTab(url: String?, isPrivate: Boolean = false): BrowserTab {
        val webView = WebView(this)
        val tab = BrowserTab(webView, isPrivate)

        webView.setBackgroundColor(getColor(R.color.bg))
        val settings = webView.settings
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true
        settings.builtInZoomControls = true
        settings.displayZoomControls = false
        settings.setSupportZoom(true)
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = true
        settings.mediaPlaybackRequiresUserGesture = false
        settings.allowFileAccess = false
        settings.allowContentAccess = false
        settings.mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
        if (isPrivate) {
            settings.cacheMode = WebSettings.LOAD_NO_CACHE
            @Suppress("DEPRECATION")
            settings.saveFormData = false
        }
        applyUserAgent(webView)
        applyExtraSettings(webView)
        if (Build.VERSION.SDK_INT >= 26) settings.setSafeBrowsingEnabled(true)
        CookieManager.getInstance().setAcceptThirdPartyCookies(webView, true)

        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val uri = request?.url
                if (uri?.scheme == HOME_SCHEME) return handleHomeAction(uri)
                return handleExternalScheme(uri)
            }

            override fun shouldInterceptRequest(
                view: WebView?,
                request: WebResourceRequest?
            ): android.webkit.WebResourceResponse? {
                if (request != null && prefs.adBlock && !request.isForMainFrame &&
                    AdBlocker.isBlocked(request.url?.host)
                ) {
                    return AdBlocker.emptyResponse()
                }
                return super.shouldInterceptRequest(view, request)
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                if (view != null && url != null && !url.startsWith("file://")) {
                    view.settings.allowFileAccess = false
                }
                tab.loading = true
                tab.progress = 5
                tab.url = url.orEmpty()
                if (tab === current) {
                    updateUi()
                    updateProgress()
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                tab.loading = false
                tab.progress = 100
                tab.url = url.orEmpty()
                tab.title = view?.title.orEmpty()
                if (view != null && prefs.nightMode) applyNightMode(view, true)
                if (view != null && tab.url.startsWith(NEWTAB_URL)) pushShortcuts(view)
                if (!tab.isPrivate) prefs.addHistory(tab.title, tab.url)
                if (tab === current) {
                    updateUi()
                    updateProgress()
                }
            }

            override fun onPageCommitVisible(view: WebView?, url: String?) {
                if (view != null && prefs.nightMode) applyNightMode(view, true)
            }

            override fun doUpdateVisitedHistory(view: WebView?, url: String?, isReload: Boolean) {
                tab.url = url.orEmpty()
                if (tab === current) updateUi()
            }
        }

        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                tab.progress = newProgress
                if (tab === current) updateProgress()
            }

            override fun onReceivedIcon(view: WebView?, icon: Bitmap?) {
                tab.favicon = icon
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                tab.title = title.orEmpty()
            }

            // target="_blank" ve window.open bağlantıları yeni sekmede açılır
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: android.os.Message?
            ): Boolean {
                val message = resultMsg ?: return false
                val transport = message.obj as? WebView.WebViewTransport ?: return false
                val created = newTab(null, tab.isPrivate)
                transport.webView = created.webView
                message.sendToTarget()
                return true
            }

            override fun onShowCustomView(
                view: View?,
                callback: WebChromeClient.CustomViewCallback?
            ) {
                if (view == null || customView != null) {
                    callback?.onCustomViewHidden()
                    return
                }
                customView = view
                customViewCallback = callback
                fullscreenContainer.addView(view)
                fullscreenContainer.visibility = View.VISIBLE
                setSystemBarsVisible(false)
            }

            override fun onHideCustomView() {
                exitFullscreen()
            }

            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: WebChromeClient.FileChooserParams?
            ): Boolean {
                val chooserIntent = fileChooserParams?.createIntent() ?: return false
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback
                return try {
                    fileChooser.launch(chooserIntent)
                    true
                } catch (e: Exception) {
                    fileCallback = null
                    false
                }
            }
        }

        webView.setDownloadListener { downloadUrl, userAgent, contentDisposition, mimeType, _ ->
            startDownload(downloadUrl, userAgent, contentDisposition, mimeType)
        }

        webView.setOnLongClickListener {
            val hit = webView.hitTestResult
            val extra = hit.extra
            when (hit.type) {
                WebView.HitTestResult.SRC_ANCHOR_TYPE -> {
                    if (extra != null) showLinkMenu(extra, null, tab.isPrivate)
                    true
                }
                WebView.HitTestResult.IMAGE_TYPE -> {
                    if (extra != null) showLinkMenu(null, extra, tab.isPrivate)
                    true
                }
                WebView.HitTestResult.SRC_IMAGE_ANCHOR_TYPE -> {
                    val handler = Handler(Looper.getMainLooper()) { m ->
                        showLinkMenu(m.data?.getString("url"), m.data?.getString("src") ?: extra, tab.isPrivate)
                        true
                    }
                    webView.requestFocusNodeHref(handler.obtainMessage())
                    true
                }
                else -> false
            }
        }

        tabs.add(tab)
        switchTo(tab)
        if (url != null) webView.loadUrl(normalizeInput(url))
        return tab
    }

    private fun switchTo(tab: BrowserTab) {
        val previous = current
        if (previous != null && previous !== tab) {
            captureThumb(previous)
            previous.webView.onPause()
            webContainer.removeView(previous.webView)
        }
        current = tab
        (tab.webView.parent as? ViewGroup)?.removeView(tab.webView)
        webContainer.addView(
            tab.webView,
            FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT,
                ViewGroup.LayoutParams.MATCH_PARENT
            )
        )
        tab.webView.onResume()
        updateUi()
        updateProgress()
    }

    private fun closeTab(tab: BrowserTab) {
        val index = tabs.indexOf(tab)
        if (index < 0) return
        tabs.removeAt(index)

        val wasCurrent = tab === current
        if (wasCurrent) current = null
        webContainer.removeView(tab.webView)
        tab.webView.stopLoading()
        tab.webView.destroy()

        if (tabs.isEmpty()) {
            newTab(NEWTAB_URL)
        } else if (wasCurrent) {
            switchTo(tabs[minOf(index, tabs.size - 1)])
        } else {
            updateUi()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Arayüzü güncelleme
    // ---------------------------------------------------------------------------------------

    private fun updateUi() {
        val tab = current ?: return
        val webView = tab.webView

        val canBack = webView.canGoBack()
        val canForward = webView.canGoForward()
        btnBack.isEnabled = canBack
        btnBack.alpha = if (canBack) 1f else 0.35f
        btnForward.isEnabled = canForward
        btnForward.alpha = if (canForward) 1f else 0.35f

        btnReload.setImageResource(if (tab.loading) R.drawable.ic_close else R.drawable.ic_refresh)
        tabCount.text = tabs.size.toString()

        val barColor = getColor(if (tab.isPrivate) R.color.private_bar else R.color.surface)
        topBar.setBackgroundColor(barColor)
        bottomBar.setBackgroundColor(barColor)
        if (tab.isPrivate && prefs.secureTabs) {
            window.addFlags(WindowManager.LayoutParams.FLAG_SECURE)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_SECURE)
        }

        val secure = tab.url.startsWith("https://")
        addressIcon.setImageResource(if (secure) R.drawable.ic_lock else R.drawable.ic_search)

        if (!addressBar.hasFocus()) {
            addressBar.setText(displayUrl(tab.url))
        }
    }

    private fun updateProgress() {
        val tab = current ?: return
        val showBar = tab.loading && tab.progress < 100
        progressBar.visibility = if (showBar) View.VISIBLE else View.INVISIBLE
        progressBar.progress = tab.progress
    }

    private fun displayUrl(url: String): String {
        return if (url.isBlank() || url.startsWith(NEWTAB_URL)) "" else url
    }

    private fun tabLabel(tab: BrowserTab): String {
        if (tab.title.isNotBlank()) return tab.title
        val host = Uri.parse(tab.url).host
        return if (!host.isNullOrBlank()) host else getString(R.string.new_tab)
    }

    // ---------------------------------------------------------------------------------------
    // Sekme listesi ve menü
    // ---------------------------------------------------------------------------------------

    // ---------------------------------------------------------------------------------------
    // Sekmeler (kart ızgarası), menü, araç kutusu ve Chrome tarzı özellikler
    // ---------------------------------------------------------------------------------------

    private fun toastText(msg: String) = Toast.makeText(this, msg, Toast.LENGTH_SHORT).show()

    private fun dpPx(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun isRealPage(url: String?) = !url.isNullOrBlank() && !url.startsWith(NEWTAB_URL)

    private fun needPage(): Boolean {
        val ok = isRealPage(current?.url)
        if (!ok) toastText("Önce bir web sayfası aç")
        return ok
    }

    /** Sekme kartlarında gösterilecek küçük önizleme resmi. */
    private fun captureThumb(tab: BrowserTab) {
        val w = tab.webView.width
        val h = tab.webView.height
        if (w <= 0 || h <= 0) return
        try {
            val scale = 0.35f
            val bmp = Bitmap.createBitmap(
                (w * scale).toInt().coerceAtLeast(1),
                (h * scale).toInt().coerceAtLeast(1),
                Bitmap.Config.ARGB_8888
            )
            val canvas = Canvas(bmp)
            canvas.scale(scale, scale)
            tab.webView.draw(canvas)
            tab.thumb = bmp
        } catch (e: Exception) {
            // önizleme alınamazsa kart boş görünür
        }
    }

    // ----- Sekme ızgarası -----------------------------------------------------------------

    private fun showTabs() {
        current?.let { captureThumb(it) }
        val dialog = Dialog(this, R.style.TabsDialog)
        val root = layoutInflater.inflate(R.layout.dialog_tabs, null)
        val grid = root.findViewById<LinearLayout>(R.id.tabsGrid)
        val search = root.findViewById<EditText>(R.id.tabsSearch)
        val modeNormal = root.findViewById<TextView>(R.id.tabsModeNormal)
        val modePrivate = root.findViewById<ImageView>(R.id.tabsModePrivate)
        var privateMode = current?.isPrivate == true

        fun refresh() {
            val q = search.text.toString().trim().lowercase()
            modeNormal.text = tabs.count { !it.isPrivate }.toString()
            modeNormal.setBackgroundResource(if (!privateMode) R.drawable.bg_pill_selected else 0)
            modeNormal.setTextColor(getColor(if (!privateMode) R.color.night else R.color.text))
            modePrivate.setBackgroundResource(if (privateMode) R.drawable.bg_pill_selected else 0)
            modePrivate.imageTintList = ColorStateList.valueOf(
                getColor(if (privateMode) R.color.night else R.color.text)
            )

            grid.removeAllViews()
            val shown = tabs.filter {
                it.isPrivate == privateMode &&
                    (q.isEmpty() || tabLabel(it).lowercase().contains(q) || it.url.lowercase().contains(q))
            }
            if (shown.isEmpty()) {
                val empty = TextView(this)
                empty.text = if (q.isEmpty()) "Bu bölümde sekme yok" else "Eşleşen sekme yok"
                empty.setTextColor(getColor(R.color.muted))
                empty.gravity = Gravity.CENTER
                empty.setPadding(0, dpPx(40), 0, 0)
                grid.addView(empty)
                return
            }
            for (pair in shown.chunked(2)) {
                val row = LinearLayout(this)
                row.orientation = LinearLayout.HORIZONTAL
                for (tab in pair) row.addView(buildTabCard(tab, row, dialog) { refresh() })
                if (pair.size == 1) {
                    val spacer = View(this)
                    val lp = LinearLayout.LayoutParams(0, 1, 1f)
                    lp.setMargins(dpPx(5), dpPx(5), dpPx(5), dpPx(5))
                    row.addView(spacer, lp)
                }
                grid.addView(
                    row,
                    LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.WRAP_CONTENT
                    )
                )
            }
        }

        root.findViewById<View>(R.id.tabsNew).setOnClickListener {
            newTab(NEWTAB_URL, privateMode)
            dialog.dismiss()
            if (!privateMode) focusAddress()
        }
        modeNormal.setOnClickListener {
            privateMode = false
            refresh()
        }
        modePrivate.setOnClickListener {
            privateMode = true
            refresh()
        }
        search.doAfterTextChanged { refresh() }
        root.findViewById<View>(R.id.tabsMore).setOnClickListener { anchor ->
            val popup = PopupMenu(this, anchor)
            popup.menu.add(0, 1, 0, if (privateMode) "Tüm gizli sekmeleri kapat" else "Tüm sekmeleri kapat")
            popup.menu.add(0, 2, 1, "Ayarlar")
            popup.setOnMenuItemClickListener { item ->
                when (item.itemId) {
                    1 -> {
                        for (t in tabs.filter { it.isPrivate == privateMode }) closeTab(t)
                        refresh()
                    }
                    2 -> {
                        dialog.dismiss()
                        startActivity(Intent(this, SettingsActivity::class.java))
                    }
                }
                true
            }
            popup.show()
        }

        refresh()
        dialog.setContentView(root)
        dialog.show()
        dialog.window?.setLayout(
            ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.MATCH_PARENT
        )
    }

    private fun buildTabCard(
        tab: BrowserTab,
        parent: ViewGroup,
        dialog: Dialog,
        onClose: () -> Unit
    ): View {
        val card = layoutInflater.inflate(R.layout.item_tab_card, parent, false)
        card.findViewById<TextView>(R.id.cardTitle).text = tabLabel(tab)

        val favicon = card.findViewById<ImageView>(R.id.cardFavicon)
        val icon = tab.favicon
        if (icon != null && !tab.isPrivate) {
            favicon.imageTintList = null
            favicon.setImageBitmap(icon)
        } else {
            favicon.setImageResource(if (tab.isPrivate) R.drawable.ic_incognito else R.drawable.ic_search)
            favicon.imageTintList = ColorStateList.valueOf(getColor(R.color.gold))
        }

        val thumb = card.findViewById<ImageView>(R.id.cardThumb)
        thumb.clipToOutline = true
        val shot = tab.thumb
        if (tab.isPrivate) {
            thumb.scaleType = ImageView.ScaleType.CENTER_INSIDE
            thumb.setPadding(dpPx(40), dpPx(40), dpPx(40), dpPx(40))
            thumb.setImageResource(R.drawable.ic_incognito)
            thumb.imageTintList = ColorStateList.valueOf(getColor(R.color.text))
        } else if (shot != null) {
            thumb.setImageBitmap(shot)
        }

        when {
            tab === current -> card.setBackgroundResource(R.drawable.bg_tab_active)
            tab.isPrivate -> card.setBackgroundResource(R.drawable.bg_tab_private)
        }
        card.setOnClickListener {
            switchTo(tab)
            dialog.dismiss()
        }
        card.findViewById<View>(R.id.cardClose).setOnClickListener {
            closeTab(tab)
            onClose()
        }
        return card
    }

    // ----- Menü ---------------------------------------------------------------------------

    private class ToolItem(val icon: Int, val label: String, val action: () -> Unit)

    private fun showMenu() {
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_list, null)
        sheet.findViewById<View>(R.id.listTitle).visibility = View.GONE
        val body = sheet.findViewById<LinearLayout>(R.id.listBody)
        val matchParent = ViewGroup.LayoutParams.MATCH_PARENT
        val wrap = ViewGroup.LayoutParams.WRAP_CONTENT

        val tab = current
        val pageUrl = tab?.url.orEmpty()
        val realPage = isRealPage(pageUrl)

        // Başlık
        val header = layoutInflater.inflate(R.layout.menu_header, body, false)
        header.findViewById<TextView>(R.id.menuVersion).text = "v" + APP_VERSION
        header.findViewById<View>(R.id.menuSettings).setOnClickListener {
            dialog.dismiss()
            startActivity(Intent(this, SettingsActivity::class.java))
        }
        body.addView(header)

        // Chrome tarzı hızlı simge satırı: ileri, yenile, favori, paylaş, site bilgisi
        val iconRow = LinearLayout(this)
        iconRow.orientation = LinearLayout.HORIZONTAL
        fun iconButton(res: Int, desc: String, tint: Int, enabled: Boolean, onClick: () -> Unit) {
            val b = ImageButton(this)
            b.setImageResource(res)
            b.imageTintList = ColorStateList.valueOf(tint)
            b.contentDescription = desc
            b.background = null
            b.isEnabled = enabled
            b.alpha = if (enabled) 1f else 0.35f
            b.setOnClickListener {
                dialog.dismiss()
                onClick()
            }
            iconRow.addView(b, LinearLayout.LayoutParams(0, dpPx(48), 1f))
        }
        val fav = realPage && prefs.isFavorite(pageUrl)
        iconButton(
            R.drawable.ic_forward, "İleri", getColor(R.color.text),
            tab?.webView?.canGoForward() == true
        ) { tab?.webView?.goForward() }
        iconButton(R.drawable.ic_refresh, "Yenile", getColor(R.color.text), true) {
            current?.webView?.reload()
        }
        iconButton(
            R.drawable.ic_star, "Favori", getColor(if (fav) R.color.gold else R.color.text), realPage
        ) {
            val added = prefs.toggleFavorite(tab?.title.orEmpty(), pageUrl)
            toastText(if (added) "Favorilere eklendi" else "Favorilerden çıkarıldı")
        }
        iconButton(R.drawable.ic_share, "Paylaş", getColor(R.color.text), realPage) { shareCurrentPage() }
        iconButton(R.drawable.ic_info, "Site bilgisi", getColor(R.color.text), realPage) { showSiteInfo() }
        body.addView(iconRow, LinearLayout.LayoutParams(matchParent, wrap))

        // Üç hızlı anahtar: veri tasarrufu, reklam engelleyici, gece modu
        val toggles = LinearLayout(this)
        toggles.orientation = LinearLayout.HORIZONTAL
        toggles.setPadding(0, dpPx(8), 0, dpPx(8))
        fun toggleTile(icon: Int, title: String, isOn: () -> Boolean, toggle: () -> Unit) {
            val tile = layoutInflater.inflate(R.layout.item_tile, toggles, false)
            val iv = tile.findViewById<ImageView>(R.id.tileIcon)
            val sub = tile.findViewById<TextView>(R.id.tileSub)
            tile.findViewById<TextView>(R.id.tileTitle).text = title
            iv.setImageResource(icon)
            sub.visibility = View.VISIBLE
            fun paint() {
                val on = isOn()
                iv.setBackgroundResource(if (on) R.drawable.bg_tile_on else R.drawable.bg_tile_off)
                iv.imageTintList = ColorStateList.valueOf(getColor(if (on) R.color.night else R.color.gold))
                sub.text = if (on) "Açık" else "Kapalı"
            }
            paint()
            tile.setOnClickListener {
                toggle()
                paint()
            }
            toggles.addView(tile)
        }
        toggleTile(R.drawable.ic_leaf, "Veri Tasarrufu", { prefs.noImages }) {
            prefs.noImages = !prefs.noImages
            for (t in tabs) applyExtraSettings(t.webView)
            if (isRealPage(current?.url)) current?.webView?.reload()
        }
        toggleTile(R.drawable.ic_shield, "Reklam Engelleyici", { prefs.adBlock }) {
            prefs.adBlock = !prefs.adBlock
            if (isRealPage(current?.url)) current?.webView?.reload()
        }
        toggleTile(R.drawable.ic_moon, "Gece Modu", { prefs.nightMode }) {
            prefs.nightMode = !prefs.nightMode
            for (t in tabs) applyNightMode(t.webView, prefs.nightMode)
        }
        body.addView(toggles, LinearLayout.LayoutParams(matchParent, wrap))

        // Liste
        addRow(body, R.drawable.ic_plus, "Yeni Sekme", null, null) {
            dialog.dismiss()
            newTab(NEWTAB_URL)
            focusAddress()
        }
        addRow(body, R.drawable.ic_incognito, "Yeni Gizli Sekme", null, null) {
            dialog.dismiss()
            newTab(NEWTAB_URL, true)
        }
        addRow(body, R.drawable.ic_star, "Favoriler", null, null) {
            dialog.dismiss()
            showFavorites()
        }
        addRow(body, R.drawable.ic_history, "Geçmiş", null, null) {
            dialog.dismiss()
            showHistory()
        }
        addRow(body, R.drawable.ic_download, "İndirilenler", null, null) {
            dialog.dismiss()
            openDownloads()
        }
        addRow(body, R.drawable.ic_offline, "Çevrimdışı sayfalar", null, null) {
            dialog.dismiss()
            showOfflinePages()
        }
        addRow(body, R.drawable.ic_focus, "Odak Modu", "Üst ve alt çubukları gizler", null) {
            dialog.dismiss()
            setFocusLevel(1)
        }
        addRow(body, R.drawable.ic_desktop, "Masaüstü sitesi", null, desktopMode) {
            setDesktopMode(!desktopMode)
        }

        // Araç kutusu
        val toolsTitle = TextView(this)
        toolsTitle.text = "Araç Kutusu"
        toolsTitle.setTextColor(getColor(R.color.gold))
        toolsTitle.textSize = 15f
        toolsTitle.typeface = android.graphics.Typeface.DEFAULT_BOLD
        toolsTitle.setPadding(dpPx(8), dpPx(16), 0, dpPx(6))
        body.addView(toolsTitle)

        val tools = listOf(
            ToolItem(R.drawable.ic_camera, "Ekran\ngörüntüsü") { saveScreenshot() },
            ToolItem(R.drawable.ic_fullscreen, "Tam ekran") { setFocusLevel(2) },
            ToolItem(R.drawable.ic_qr, "QR tara") { scanQr() },
            ToolItem(R.drawable.ic_pin, "Ana ekrana\nekle") { addToHomeScreen() },
            ToolItem(R.drawable.ic_download, "Videoyu indir") { downloadVideo() },
            ToolItem(R.drawable.ic_search, "Sayfada bul") { showFindDialog() },
            ToolItem(R.drawable.ic_reader, "Okuma modu") { enterReaderMode() },
            ToolItem(R.drawable.ic_translate, "Çevir") { translatePage() },
            ToolItem(R.drawable.ic_save, "Çevrimdışı\nkaydet") { saveOffline() },
            ToolItem(R.drawable.ic_print, "Yazdır / PDF") { printPage() },
            ToolItem(R.drawable.ic_textsize, "Metin boyutu") { showTextSizeDialog() },
            ToolItem(R.drawable.ic_bulb, "Ekranı açık\ntut") { toggleKeepScreen() }
        )
        for (rowItems in tools.chunked(4)) {
            val row = LinearLayout(this)
            row.orientation = LinearLayout.HORIZONTAL
            for (item in rowItems) {
                val tile = layoutInflater.inflate(R.layout.item_tile, row, false)
                tile.findViewById<ImageView>(R.id.tileIcon).setImageResource(item.icon)
                tile.findViewById<TextView>(R.id.tileTitle).text = item.label
                tile.setOnClickListener {
                    dialog.dismiss()
                    item.action()
                }
                row.addView(tile)
            }
            body.addView(row, LinearLayout.LayoutParams(matchParent, wrap))
        }

        dialog.setContentView(sheet)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    // ----- Odak / tam ekran ---------------------------------------------------------------

    /** 0 = normal, 1 = odak (çubuklar gizli), 2 = tam ekran (sistem çubukları da gizli). */
    private fun setFocusLevel(level: Int) {
        focusLevel = level
        val visibility = if (level >= 1) View.GONE else View.VISIBLE
        topBar.visibility = visibility
        bottomBar.visibility = visibility
        setSystemBarsVisible(level < 2)
        if (level > 0) toastText("Çıkmak için geri tuşuna bas")
    }

    private fun toggleKeepScreen() {
        prefs.keepScreenOn = !prefs.keepScreenOn
        applyKeepScreen()
        toastText("Ekranı açık tut: " + if (prefs.keepScreenOn) "açık" else "kapalı")
    }

    private fun applyKeepScreen() {
        if (prefs.keepScreenOn) {
            window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        } else {
            window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        }
    }

    // ----- Sayfa ayarları -----------------------------------------------------------------

    private fun applyExtraSettings(webView: WebView) {
        webView.settings.blockNetworkImage = prefs.noImages
        webView.settings.textZoom = prefs.textZoom
    }

    /** Sayfa renklerini ters çevirerek gece modu sağlar; resim ve videolar eski haline döndürülür. */
    private fun applyNightMode(webView: WebView, on: Boolean) {
        if (webView.url?.startsWith(NEWTAB_URL) == true) return
        val js = """
            (function(){
              var id='gk-night';
              var el=document.getElementById(id);
              if($on){
                if(!el){
                  el=document.createElement('style');
                  el.id=id;
                  el.textContent='html{filter:invert(1) hue-rotate(180deg)!important;background:#fff}'
                    +'img,video,canvas,picture{filter:invert(1) hue-rotate(180deg)!important}';
                  (document.head||document.documentElement).appendChild(el);
                }
              } else if(el){ el.remove(); }
            })();
        """.trimIndent()
        webView.evaluateJavascript(js, null)
    }

    private fun showTextSizeDialog() {
        val labels = arrayOf("Küçük (%85)", "Normal (%100)", "Büyük (%125)", "Çok büyük (%150)")
        val values = intArrayOf(85, 100, 125, 150)
        var selected = values.indexOf(prefs.textZoom)
        if (selected < 0) selected = 1
        AlertDialog.Builder(this)
            .setTitle("Metin boyutu")
            .setSingleChoiceItems(labels, selected) { d, which ->
                prefs.textZoom = values[which]
                for (t in tabs) applyExtraSettings(t.webView)
                d.dismiss()
            }
            .setNegativeButton("Kapat", null)
            .show()
    }

    private fun showFindDialog() {
        if (!needPage()) return
        val webView = current?.webView ?: return
        val input = EditText(this)
        input.hint = "Sayfada ara"
        input.setSingleLine()
        val pad = dpPx(20)
        val box = FrameLayout(this)
        box.setPadding(pad, pad / 2, pad, 0)
        box.addView(input)

        val dialog = AlertDialog.Builder(this)
            .setTitle("Sayfada ara")
            .setView(box)
            .setPositiveButton("Sonraki", null)
            .setNeutralButton("Önceki", null)
            .setNegativeButton("Kapat", null)
            .create()
        dialog.setOnDismissListener { webView.clearMatches() }
        dialog.show()

        var lastQuery = ""
        // Düğmeler kendiliğinden pencereyi kapatmasın diye sonradan bağlanır.
        dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
            val q = input.text.toString()
            if (q.isBlank()) return@setOnClickListener
            if (q != lastQuery) {
                lastQuery = q
                webView.findAllAsync(q)
            } else {
                webView.findNext(true)
            }
        }
        dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener {
            if (lastQuery.isNotBlank()) webView.findNext(false)
        }
    }

    /** Sayfadaki başlık ve paragrafları çıkarıp sade bir okuma sayfası oluşturur. */
    private fun enterReaderMode() {
        if (!needPage()) return
        val tab = current ?: return
        val js = """
            (function(){
              var r=document.querySelector('article')||document.querySelector('main')||document.body;
              var n=r.querySelectorAll('h1,h2,h3,p,li,blockquote');
              var o=[];
              for(var i=0;i<n.length;i++){
                var t=(n[i].innerText||'').trim();
                if(t.length>1){
                  var g=n[i].tagName.toLowerCase();
                  o.push('<'+g+'>'+t.replace(/&/g,'&amp;').replace(/</g,'&lt;')+'</'+g+'>');
                }
              }
              return o.join('');
            })()
        """.trimIndent()
        tab.webView.evaluateJavascript(js) { raw ->
            if (raw == null) return@evaluateJavascript
            val body = try {
                JSONTokener(raw).nextValue() as? String
            } catch (e: Exception) {
                null
            }
            if (body.isNullOrBlank()) {
                toastText("Okunabilir içerik bulunamadı")
                return@evaluateJavascript
            }
            val title = tab.title.replace("&", "&amp;").replace("<", "&lt;")
            val html = "<html><head><meta name='viewport' content='width=device-width,initial-scale=1'>" +
                "<style>body{background:#040E16;color:#F3E7C9;font-family:Georgia,serif;font-size:19px;" +
                "line-height:1.7;padding:18px;max-width:720px;margin:auto}" +
                "h1,h2,h3{color:#F5B942;line-height:1.3}" +
                "blockquote{border-left:3px solid #F5B942;margin-left:0;padding-left:14px;color:#B7A77F}" +
                "</style></head><body><h1>" + title + "</h1>" + body + "</body></html>"
            tab.webView.loadDataWithBaseURL(tab.url, html, "text/html", "utf-8", null)
        }
    }

    private fun translatePage() {
        if (!needPage()) return
        val url = current?.url.orEmpty()
        current?.webView?.loadUrl("https://translate.google.com/translate?sl=auto&tl=tr&u=" + Uri.encode(url))
    }

    private fun copyText(text: String) {
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("url", text))
        toastText("Bağlantı kopyalandı")
    }

    private fun shareText(text: String) {
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, text)
        startActivity(Intent.createChooser(send, getString(R.string.share_via)))
    }

    private fun printPage() {
        if (!needPage()) return
        val tab = current ?: return
        val name = tab.title.ifBlank { "Sayfa" }.take(40)
        val pm = getSystemService(Context.PRINT_SERVICE) as PrintManager
        pm.print(name, tab.webView.createPrintDocumentAdapter(name), PrintAttributes.Builder().build())
    }

    private fun addToHomeScreen() {
        if (!needPage()) return
        val tab = current ?: return
        val url = tab.url
        if (!ShortcutManagerCompat.isRequestPinShortcutSupported(this)) {
            toastText("Başlatıcınız bu özelliği desteklemiyor")
            return
        }
        val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url), this, MainActivity::class.java)
        val info = ShortcutInfoCompat.Builder(this, "gk_" + url.hashCode())
            .setShortLabel(tab.title.ifBlank { url }.take(24))
            .setIcon(IconCompat.createWithResource(this, R.mipmap.ic_launcher))
            .setIntent(intent)
            .build()
        ShortcutManagerCompat.requestPinShortcut(this, info, null)
    }

    // ----- Ekran görüntüsü, QR, video -----------------------------------------------------

    @Suppress("DEPRECATION")
    private fun saveScreenshot() {
        val wv = current?.webView ?: return
        if (wv.width <= 0 || wv.height <= 0) return
        val bmp = Bitmap.createBitmap(wv.width, wv.height, Bitmap.Config.ARGB_8888)
        wv.draw(Canvas(bmp))
        val name = "Gokboru_" + System.currentTimeMillis() + ".png"
        try {
            if (Build.VERSION.SDK_INT >= 29) {
                val values = ContentValues()
                values.put(MediaStore.Images.Media.DISPLAY_NAME, name)
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                values.put(MediaStore.Images.Media.RELATIVE_PATH, "Pictures/Gokboru")
                val uri = contentResolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values)
                    ?: throw IllegalStateException("kayıt oluşturulamadı")
                contentResolver.openOutputStream(uri)?.use { bmp.compress(Bitmap.CompressFormat.PNG, 100, it) }
            } else {
                MediaStore.Images.Media.insertImage(contentResolver, bmp, name, null)
                    ?: throw IllegalStateException("kayıt oluşturulamadı")
            }
            toastText("Ekran görüntüsü kaydedildi")
        } catch (e: Exception) {
            toastText("Ekran görüntüsü kaydedilemedi")
        }
    }

    /** Google'ın QR/barkod tarayıcısını kullanır (Google Play hizmetleri gerekir, kamera izni gerekmez). */
    private fun scanQr() {
        try {
            GmsBarcodeScanning.getClient(this).startScan()
                .addOnSuccessListener { barcode ->
                    val value = barcode.rawValue
                    if (!value.isNullOrBlank()) loadFromInput(value)
                }
                .addOnFailureListener {
                    toastText("QR okunamadı veya tarama iptal edildi")
                }
        } catch (e: Exception) {
            toastText("QR tarama bu cihazda kullanılamıyor")
        }
    }

    private fun downloadVideo() {
        if (!needPage()) return
        val tab = current ?: return
        val js = "(function(){var v=document.querySelector('video');if(!v)return '';" +
            "var s=v.currentSrc||v.src||'';if(!s){var so=v.querySelector('source');if(so)s=so.src;}" +
            "return s;})()"
        tab.webView.evaluateJavascript(js) { raw ->
            val parsed = try {
                JSONTokener(raw ?: "\"\"").nextValue() as? String
            } catch (e: Exception) {
                null
            }
            val src = parsed ?: ""
            if (src.startsWith("http") && !src.contains(".m3u8")) {
                startDownload(src, tab.webView.settings.userAgentString, null, null)
            } else {
                toastText("Bu sayfadaki videonun doğrudan indirme bağlantısı yok")
            }
        }
    }

    // ----- Çevrimdışı sayfalar ------------------------------------------------------------

    private fun saveOffline() {
        if (!needPage()) return
        val tab = current ?: return
        val dir = File(filesDir, "offline")
        dir.mkdirs()
        val path = File(dir, "p" + System.currentTimeMillis() + ".mht").absolutePath
        tab.webView.saveWebArchive(path, false) { saved ->
            if (saved != null) {
                prefs.addOffline(tab.title.ifBlank { tab.url }, saved)
                toastText("Sayfa çevrimdışı kaydedildi")
            } else {
                toastText("Sayfa kaydedilemedi")
            }
        }
    }

    private fun showOfflinePages() {
        val pages = prefs.offline()
        if (pages.isEmpty()) {
            toastText("Kayıtlı çevrimdışı sayfa yok")
            return
        }
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_list, null)
        sheet.findViewById<TextView>(R.id.listTitle).text = "Çevrimdışı sayfalar (silmek için basılı tut)"
        val body = sheet.findViewById<LinearLayout>(R.id.listBody)
        for (page in pages) {
            val row = addRow(body, R.drawable.ic_offline, page.title, null, null) {
                dialog.dismiss()
                openOffline(page.url)
            }
            row.setOnLongClickListener {
                File(page.url).delete()
                prefs.removeOffline(page.url)
                dialog.dismiss()
                showOfflinePages()
                true
            }
        }
        dialog.setContentView(sheet)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    private fun openOffline(path: String) {
        val tab = current ?: return
        tab.webView.settings.allowFileAccess = true
        tab.webView.loadUrl("file://" + path)
    }

    // ----- Bağlantı / resim menüsü (uzun basma) ---------------------------------------------

    private fun showLinkMenu(link: String?, image: String?, isPrivate: Boolean) {
        val labels = mutableListOf<String>()
        val actions = mutableListOf<() -> Unit>()
        if (link != null) {
            labels.add("Yeni sekmede aç")
            actions.add { newTab(link, isPrivate) }
            labels.add("Gizli sekmede aç")
            actions.add { newTab(link, true) }
            labels.add("Bağlantıyı kopyala")
            actions.add { copyText(link) }
            labels.add("Bağlantıyı paylaş")
            actions.add { shareText(link) }
        }
        if (image != null) {
            labels.add("Resmi indir")
            actions.add { startDownload(image, current?.webView?.settings?.userAgentString, null, null) }
            labels.add("Resmi yeni sekmede aç")
            actions.add { newTab(image, isPrivate) }
        }
        if (labels.isEmpty()) return
        AlertDialog.Builder(this)
            .setItems(labels.toTypedArray()) { _, which -> actions[which]() }
            .show()
    }

    private fun showSiteInfo() {
        val url = current?.url.orEmpty()
        if (!isRealPage(url)) return
        val secure = url.startsWith("https://")
        val host = Uri.parse(url).host ?: url
        val note = if (secure) {
            "Bağlantı güvenli (HTTPS).\n\n"
        } else {
            "Bağlantı güvenli değil (HTTP). Bu sayfaya şifre veya kart bilgisi girme.\n\n"
        }
        AlertDialog.Builder(this)
            .setTitle(host)
            .setMessage(note + url)
            .setPositiveButton("Kapat", null)
            .setNeutralButton("Bağlantıyı kopyala") { _, _ -> copyText(url) }
            .show()
    }

    // ----- Hızlı erişim kısayolları -------------------------------------------------------

    private fun pushShortcuts(webView: WebView) {
        val arr = JSONArray()
        for (e in prefs.shortcuts()) arr.put(JSONObject().put("t", e.title).put("u", e.url))
        webView.evaluateJavascript("if(window.setShortcuts)setShortcuts(" + arr.toString() + ");", null)
    }

    private fun refreshHomeShortcuts() {
        val tab = current ?: return
        if (tab.url.startsWith(NEWTAB_URL)) pushShortcuts(tab.webView)
    }

    private fun showAddShortcutDialog() {
        val pad = dpPx(20)
        val box = LinearLayout(this)
        box.orientation = LinearLayout.VERTICAL
        box.setPadding(pad, pad / 2, pad, 0)
        val nameInput = EditText(this)
        nameInput.hint = "Ad (ör. Haberler)"
        nameInput.setSingleLine()
        val addrInput = EditText(this)
        addrInput.hint = "Adres (ör. site.com)"
        addrInput.setSingleLine()
        addrInput.inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
        box.addView(nameInput)
        box.addView(addrInput)
        AlertDialog.Builder(this)
            .setTitle("Hızlı erişime ekle")
            .setView(box)
            .setPositiveButton("Ekle") { _, _ ->
                val raw = addrInput.text.toString().trim()
                if (raw.isNotEmpty()) {
                    val url = normalizeInput(raw)
                    val name = nameInput.text.toString().trim()
                        .ifEmpty { Uri.parse(url).host?.removePrefix("www.") ?: raw }
                    prefs.addShortcut(name, url)
                    refreshHomeShortcuts()
                }
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun confirmDeleteShortcut(index: Int) {
        val list = prefs.shortcuts()
        if (index !in list.indices) return
        AlertDialog.Builder(this)
            .setTitle(list[index].title)
            .setMessage("Bu kısayol silinsin mi?")
            .setPositiveButton("Sil") { _, _ ->
                prefs.removeShortcut(index)
                refreshHomeShortcuts()
            }
            .setNegativeButton("Vazgeç", null)
            .show()
    }

    private fun openDownloads() {
        try {
            startActivity(Intent(DownloadManager.ACTION_VIEW_DOWNLOADS))
        } catch (e: Exception) {
            Toast.makeText(this, R.string.download_failed, Toast.LENGTH_SHORT).show()
        }
    }

    /** Menü/liste satırı ekler. switchState null değilse sağda anahtar gösterilir. */
    private fun addRow(
        container: LinearLayout,
        icon: Int,
        title: String,
        sub: String?,
        switchState: Boolean?,
        radioState: Boolean? = null,
        onClick: () -> Unit
    ): View {
        val row = layoutInflater.inflate(R.layout.item_row, container, false)
        row.findViewById<ImageView>(R.id.rowIcon).setImageResource(icon)
        row.findViewById<TextView>(R.id.rowTitle).text = title
        val subView = row.findViewById<TextView>(R.id.rowSub)
        if (!sub.isNullOrBlank()) {
            subView.text = sub
            subView.visibility = View.VISIBLE
        }
        val switch = row.findViewById<SwitchCompat>(R.id.rowSwitch)
        if (radioState != null) {
            val radio = row.findViewById<android.widget.RadioButton>(R.id.rowRadio)
            radio.visibility = View.VISIBLE
            radio.isChecked = radioState
            row.setOnClickListener { onClick() }
        } else if (switchState != null) {
            switch.visibility = View.VISIBLE
            switch.isChecked = switchState
            row.setOnClickListener {
                switch.isChecked = !switch.isChecked
                onClick()
            }
        } else {
            row.setOnClickListener { onClick() }
        }
        container.addView(row)
        return row
    }

    private fun showFavorites() {
        showEntries(R.string.menu_favorites, prefs.favorites(), R.string.empty_favorites, false)
    }

    private fun showHistory() {
        showEntries(R.string.menu_history, prefs.history(), R.string.empty_history, true)
    }

    private fun showEntries(titleRes: Int, entries: List<Prefs.Entry>, emptyRes: Int, isHistory: Boolean) {
        val dialog = BottomSheetDialog(this)
        val sheet = layoutInflater.inflate(R.layout.sheet_list, null)
        sheet.findViewById<TextView>(R.id.listTitle).setText(titleRes)
        val body = sheet.findViewById<LinearLayout>(R.id.listBody)

        if (entries.isEmpty()) {
            val empty = TextView(this)
            empty.setText(emptyRes)
            empty.setTextColor(getColor(R.color.muted))
            empty.setPadding(16, 24, 16, 24)
            body.addView(empty)
        }
        if (isHistory && entries.isNotEmpty()) {
            addRow(body, R.drawable.ic_trash, getString(R.string.clear_history), null, null) {
                prefs.clearHistory()
                dialog.dismiss()
                Toast.makeText(this, R.string.history_cleared, Toast.LENGTH_SHORT).show()
            }
        }
        for (entry in entries) {
            val row = addRow(
                body,
                if (isHistory) R.drawable.ic_history else R.drawable.ic_star,
                entry.title,
                entry.url,
                null
            ) {
                dialog.dismiss()
                current?.webView?.loadUrl(entry.url)
            }
            if (!isHistory) {
                row.setOnLongClickListener {
                    prefs.toggleFavorite(entry.title, entry.url)
                    dialog.dismiss()
                    Toast.makeText(this, R.string.favorite_removed, Toast.LENGTH_SHORT).show()
                    true
                }
            }
        }

        dialog.setContentView(sheet)
        dialog.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        dialog.show()
    }

    /** Ana sayfadaki gokboru:// bağlantıları. */
    private fun handleHomeAction(uri: Uri): Boolean {
        when (uri.host) {
            "favorites" -> showFavorites()
            "history" -> showHistory()
            "private" -> newTab(NEWTAB_URL, true)
            "tabs" -> showTabs()
            "mobile" -> setDesktopMode(false)
            "desktop" -> setDesktopMode(true)
            "adblock" -> {
                prefs.adBlock = !prefs.adBlock
                Toast.makeText(
                    this,
                    if (prefs.adBlock) R.string.adblock_on else R.string.adblock_off,
                    Toast.LENGTH_SHORT
                ).show()
            }
            "settings" -> startActivity(Intent(this, SettingsActivity::class.java))
            "addshortcut" -> showAddShortcutDialog()
            "delshortcut" -> confirmDeleteShortcut(uri.getQueryParameter("i")?.toIntOrNull() ?: -1)
        }
        return true
    }

    private fun startVoiceSearch() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
        intent.putExtra(
            RecognizerIntent.EXTRA_LANGUAGE_MODEL,
            RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
        )
        intent.putExtra(RecognizerIntent.EXTRA_PROMPT, getString(R.string.voice_prompt))
        try {
            voiceLauncher.launch(intent)
        } catch (e: ActivityNotFoundException) {
            Toast.makeText(this, R.string.voice_unavailable, Toast.LENGTH_SHORT).show()
        }
    }

    /**
     * Üst veya alt çubuk üzerinde kaydırma hareketleri:
     * sağa = geri, sola = ileri, yukarı = yeni sekme, aşağı = menü.
     */
    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        when (ev.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                gestureStartX = ev.rawX
                gestureStartY = ev.rawY
                gestureOnBar = prefs.gestures &&
                    (isOverView(topBar, ev) || isOverView(bottomBar, ev))
            }
            MotionEvent.ACTION_UP -> {
                if (gestureOnBar) {
                    gestureOnBar = false
                    val dx = ev.rawX - gestureStartX
                    val dy = ev.rawY - gestureStartY
                    val minDistance = resources.displayMetrics.density * 80f
                    val horizontal = Math.abs(dx) > minDistance && Math.abs(dy) < Math.abs(dx) / 2
                    val vertical = Math.abs(dy) > minDistance && Math.abs(dx) < Math.abs(dy) / 2
                    if (horizontal || vertical) {
                        ev.action = MotionEvent.ACTION_CANCEL
                        super.dispatchTouchEvent(ev)
                        val webView = current?.webView
                        if (horizontal) {
                            if (dx > 0) {
                                if (webView != null && webView.canGoBack()) webView.goBack()
                            } else {
                                if (webView != null && webView.canGoForward()) webView.goForward()
                            }
                        } else if (dy < 0) {
                            newTab(NEWTAB_URL)
                        } else {
                            showMenu()
                        }
                        return true
                    }
                }
            }
            MotionEvent.ACTION_CANCEL -> gestureOnBar = false
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun isOverView(view: View, ev: MotionEvent): Boolean {
        val loc = IntArray(2)
        view.getLocationOnScreen(loc)
        return ev.rawX >= loc[0] && ev.rawX <= loc[0] + view.width &&
            ev.rawY >= loc[1] && ev.rawY <= loc[1] + view.height
    }

    private fun shareCurrentPage() {
        val url = current?.url.orEmpty()
        if (url.isBlank() || url.startsWith(NEWTAB_URL)) return
        val send = Intent(Intent.ACTION_SEND)
        send.type = "text/plain"
        send.putExtra(Intent.EXTRA_TEXT, url)
        startActivity(Intent.createChooser(send, getString(R.string.share_via)))
    }

    private fun setDesktopMode(enabled: Boolean) {
        if (desktopMode == enabled) return
        desktopMode = enabled
        for (tab in tabs) applyUserAgent(tab.webView)
        val url = current?.url.orEmpty()
        if (url.isNotBlank() && !url.startsWith(NEWTAB_URL)) current?.webView?.reload()
    }

    private fun applyUserAgent(webView: WebView) {
        webView.settings.userAgentString = if (desktopMode) DESKTOP_UA else mobileUserAgent
    }

    private fun clearBrowsingData() {
        CookieManager.getInstance().removeAllCookies(null)
        WebStorage.getInstance().deleteAllData()
        prefs.clearHistory()
        for (tab in tabs) {
            tab.webView.clearCache(true)
            tab.webView.clearHistory()
        }
        Toast.makeText(this, R.string.data_cleared, Toast.LENGTH_SHORT).show()
        updateUi()
    }

    // ---------------------------------------------------------------------------------------
    // Gezinme yardımcıları
    // ---------------------------------------------------------------------------------------

    private fun loadFromInput(input: String) {
        val text = input.trim()
        if (text.isEmpty()) return
        current?.webView?.loadUrl(normalizeInput(text))
    }

    private fun normalizeInput(input: String): String {
        val text = input.trim()
        if (text.isEmpty()) return NEWTAB_URL
        if (Regex("^(https?|file|about):", RegexOption.IGNORE_CASE).containsMatchIn(text)) {
            return text
        }
        if (!text.contains(' ')) {
            val localHost = Regex("^localhost(:\\d+)?([/?#].*)?$", RegexOption.IGNORE_CASE)
            val ipAddress = Regex("^\\d{1,3}(\\.\\d{1,3}){3}(:\\d+)?([/?#].*)?$")
            val domain = Regex("^[\\w-]+(\\.[\\w-]+)+(:\\d+)?([/?#].*)?$")
            if (localHost.matches(text) || ipAddress.matches(text)) return "http://$text"
            if (domain.matches(text)) return "https://$text"
        }
        return prefs.searchUrl() + Uri.encode(text)
    }

    /** http/https dışındaki bağlantıları (tel:, mailto:, intent: ...) ilgili uygulamaya verir. */
    private fun handleExternalScheme(uri: Uri?): Boolean {
        val scheme = uri?.scheme?.lowercase() ?: return false
        val internalSchemes = listOf("http", "https", "file", "about", "javascript", "data", "blob")
        if (scheme in internalSchemes) return false
        try {
            val intent = if (scheme == "intent") {
                Intent.parseUri(uri.toString(), Intent.URI_INTENT_SCHEME)
            } else {
                Intent(Intent.ACTION_VIEW, uri)
            }
            intent.addCategory(Intent.CATEGORY_BROWSABLE)
            intent.component = null
            intent.selector = null
            startActivity(intent)
        } catch (e: Exception) {
            // Açacak uygulama yoksa sessizce vazgeç
        }
        return true
    }

    private fun startDownload(
        url: String,
        userAgent: String?,
        contentDisposition: String?,
        mimeType: String?
    ) {
        try {
            val request = DownloadManager.Request(Uri.parse(url))
            if (mimeType != null) request.setMimeType(mimeType)
            if (userAgent != null) request.addRequestHeader("User-Agent", userAgent)
            val cookies = CookieManager.getInstance().getCookie(url)
            if (cookies != null) request.addRequestHeader("Cookie", cookies)
            val fileName = URLUtil.guessFileName(url, contentDisposition, mimeType)
            request.setTitle(fileName)
            request.setNotificationVisibility(
                DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED
            )
            request.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, fileName)
            val manager = getSystemService(Context.DOWNLOAD_SERVICE) as DownloadManager
            manager.enqueue(request)
            Toast.makeText(
                this,
                getString(R.string.download_started, fileName),
                Toast.LENGTH_SHORT
            ).show()
        } catch (e: Exception) {
            Toast.makeText(this, R.string.download_failed, Toast.LENGTH_SHORT).show()
        }
    }

    // ---------------------------------------------------------------------------------------
    // Geri tuşu, klavye, tam ekran
    // ---------------------------------------------------------------------------------------

    private fun handleBack() {
        if (focusLevel > 0) {
            setFocusLevel(0)
            return
        }
        if (customView != null) {
            exitFullscreen()
            return
        }
        val tab = current
        if (tab != null && tab.webView.canGoBack()) {
            tab.webView.goBack()
            return
        }
        if (tab != null && tabs.size > 1) {
            closeTab(tab)
            return
        }
        val now = System.currentTimeMillis()
        if (now - lastBackPress < 2000) {
            finish()
        } else {
            lastBackPress = now
            Toast.makeText(this, R.string.press_back_again, Toast.LENGTH_SHORT).show()
        }
    }

    private fun focusAddress() {
        addressBar.requestFocus()
        val manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        manager.showSoftInput(addressBar, InputMethodManager.SHOW_IMPLICIT)
    }

    private fun hideKeyboard(view: View) {
        val manager = getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        manager.hideSoftInputFromWindow(view.windowToken, 0)
    }

    private fun exitFullscreen() {
        val view = customView ?: return
        val callback = customViewCallback
        customView = null
        customViewCallback = null
        fullscreenContainer.removeView(view)
        fullscreenContainer.visibility = View.GONE
        setSystemBarsVisible(true)
        callback?.onCustomViewHidden()
    }

    private fun setSystemBarsVisible(visible: Boolean) {
        val controller = WindowCompat.getInsetsController(window, window.decorView)
        if (visible) {
            controller.show(WindowInsetsCompat.Type.systemBars())
        } else {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
        }
    }
}
