package com.gokboru.browser

import android.webkit.WebResourceResponse
import java.io.ByteArrayInputStream

/**
 * Basit alan adı tabanlı reklam/izleyici engelleyici.
 * Not: Bu bir uBlock gibi tam bir filtre motoru değildir; yaygın reklam ağlarını engeller.
 * YouTube gibi sitelerin kendi içinden gelen reklamlarını engelleyemez.
 */
object AdBlocker {

    private val hosts = hashSetOf(
        "doubleclick.net", "googlesyndication.com", "googleadservices.com",
        "adservice.google.com", "pagead2.googlesyndication.com", "google-analytics.com",
        "googletagmanager.com", "googletagservices.com", "adnxs.com", "adsrvr.org",
        "advertising.com", "taboola.com", "outbrain.com", "criteo.com", "criteo.net",
        "pubmatic.com", "rubiconproject.com", "openx.net", "casalemedia.com",
        "smartadserver.com", "moatads.com", "scorecardresearch.com", "quantserve.com",
        "amazon-adsystem.com", "adform.net", "yieldmo.com", "mgid.com", "revcontent.com",
        "popads.net", "propellerads.com", "adsterra.com", "exoclick.com", "juicyads.com",
        "hotjar.com", "mixpanel.com", "facebook.net", "ads.yahoo.com", "adcolony.com",
        "applovin.com", "unity3d.com", "inmobi.com", "mopub.com", "yandexadexchange.net",
        "an.yandex.ru", "adriver.ru", "teads.tv", "zedo.com", "adtech.com", "bidswitch.net"
    )

    fun isBlocked(host: String?): Boolean {
        if (host.isNullOrEmpty()) return false
        var h = host.lowercase()
        while (true) {
            if (h in hosts) return true
            val dot = h.indexOf('.')
            if (dot < 0) return false
            h = h.substring(dot + 1)
            if (!h.contains('.')) return false
        }
    }

    fun emptyResponse(): WebResourceResponse =
        WebResourceResponse("text/plain", "utf-8", ByteArrayInputStream(ByteArray(0)))
}
