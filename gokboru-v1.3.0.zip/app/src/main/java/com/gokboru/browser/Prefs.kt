package com.gokboru.browser

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Ayarlar, favoriler ve geçmiş burada saklanır (SharedPreferences). */
class Prefs(context: Context) {

    class Entry(val title: String, val url: String)

    private val sp = context.applicationContext
        .getSharedPreferences("gokboru", Context.MODE_PRIVATE)

    var adBlock: Boolean
        get() = sp.getBoolean("adblock", true)
        set(value) {
            sp.edit().putBoolean("adblock", value).apply()
        }

    var desktopDefault: Boolean
        get() = sp.getBoolean("desktop_default", false)
        set(value) {
            sp.edit().putBoolean("desktop_default", value).apply()
        }

    var gestures: Boolean
        get() = sp.getBoolean("gestures", true)
        set(value) {
            sp.edit().putBoolean("gestures", value).apply()
        }

    var secureTabs: Boolean
        get() = sp.getBoolean("secure_tabs", true)
        set(value) {
            sp.edit().putBoolean("secure_tabs", value).apply()
        }

    var nightMode: Boolean
        get() = sp.getBoolean("night_mode", false)
        set(value) {
            sp.edit().putBoolean("night_mode", value).apply()
        }

    var noImages: Boolean
        get() = sp.getBoolean("no_images", false)
        set(value) {
            sp.edit().putBoolean("no_images", value).apply()
        }

    var keepScreenOn: Boolean
        get() = sp.getBoolean("keep_screen_on", false)
        set(value) {
            sp.edit().putBoolean("keep_screen_on", value).apply()
        }

    var textZoom: Int
        get() = sp.getInt("text_zoom", 100).coerceIn(50, 200)
        set(value) {
            sp.edit().putInt("text_zoom", value).apply()
        }

    var searchIndex: Int
        get() = sp.getInt("search_engine", 0).coerceIn(0, ENGINES.size - 1)
        set(value) {
            sp.edit().putInt("search_engine", value).apply()
        }

    fun searchUrl(): String = ENGINES[searchIndex].second

    // --- Favoriler ---------------------------------------------------------------------

    fun favorites(): List<Entry> = readList("favorites")

    fun isFavorite(url: String): Boolean = favorites().any { it.url == url }

    /** Favoriyse çıkarır, değilse ekler. Eklendiyse true döner. */
    fun toggleFavorite(title: String, url: String): Boolean {
        val list = favorites().toMutableList()
        val existing = list.indexOfFirst { it.url == url }
        val added: Boolean
        if (existing >= 0) {
            list.removeAt(existing)
            added = false
        } else {
            list.add(0, Entry(title.ifBlank { url }, url))
            added = true
        }
        writeList("favorites", list)
        return added
    }

    // --- Geçmiş ------------------------------------------------------------------------

    fun history(): List<Entry> = readList("history")

    fun addHistory(title: String, url: String) {
        if (url.isBlank() || url.startsWith("file:") || url.startsWith("about:")) return
        val list = history().toMutableList()
        list.removeAll { it.url == url }
        list.add(0, Entry(title.ifBlank { url }, url))
        while (list.size > MAX_HISTORY) list.removeAt(list.size - 1)
        writeList("history", list)
    }

    fun clearHistory() {
        sp.edit().remove("history").apply()
    }

    // --- Hızlı erişim kısayolları ----------------------------------------------------------

    fun shortcuts(): List<Entry> =
        if (!sp.contains("shortcuts")) DEFAULT_SHORTCUTS else readList("shortcuts")

    fun addShortcut(title: String, url: String) {
        val list = shortcuts().toMutableList()
        list.add(Entry(title, url))
        writeList("shortcuts", list)
    }

    fun removeShortcut(index: Int) {
        val list = shortcuts().toMutableList()
        if (index in list.indices) {
            list.removeAt(index)
            writeList("shortcuts", list)
        }
    }

    // --- Çevrimdışı sayfalar ---------------------------------------------------------------

    fun offline(): List<Entry> = readList("offline")

    fun addOffline(title: String, path: String) {
        val list = offline().toMutableList()
        list.removeAll { it.url == path }
        list.add(0, Entry(title.ifBlank { path }, path))
        writeList("offline", list)
    }

    fun removeOffline(path: String) {
        writeList("offline", offline().filter { it.url != path })
    }

    // --- Yardımcılar -------------------------------------------------------------------

    private fun readList(key: String): List<Entry> {
        val raw = sp.getString(key, null) ?: return emptyList()
        return try {
            val array = JSONArray(raw)
            val result = ArrayList<Entry>()
            for (i in 0 until array.length()) {
                val obj = array.getJSONObject(i)
                result.add(Entry(obj.optString("t"), obj.optString("u")))
            }
            result
        } catch (e: Exception) {
            emptyList()
        }
    }

    private fun writeList(key: String, list: List<Entry>) {
        val array = JSONArray()
        for (entry in list) {
            val obj = JSONObject()
            obj.put("t", entry.title)
            obj.put("u", entry.url)
            array.put(obj)
        }
        sp.edit().putString(key, array.toString()).apply()
    }

    companion object {
        const val MAX_HISTORY = 200

        val DEFAULT_SHORTCUTS = listOf(
            Entry("Google", "https://www.google.com"),
            Entry("YouTube", "https://m.youtube.com"),
            Entry("Vikipedi", "https://tr.wikipedia.org"),
            Entry("Instagram", "https://www.instagram.com")
        )

        val ENGINES = listOf(
            "Google" to "https://www.google.com/search?q=",
            "DuckDuckGo" to "https://duckduckgo.com/?q=",
            "Bing" to "https://www.bing.com/search?q=",
            "Yandex" to "https://yandex.com.tr/search/?text="
        )
    }
}
