package com.gokboru.browser

import android.os.Bundle
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.WebStorage
import android.widget.ImageButton
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.SwitchCompat

class SettingsActivity : AppCompatActivity() {

    private lateinit var prefs: Prefs
    private lateinit var list: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_settings)
        prefs = Prefs(this)
        list = findViewById(R.id.settingsList)
        findViewById<ImageButton>(R.id.settingsBack).setOnClickListener { finish() }
        build()
    }

    private fun build() {
        list.removeAllViews()

        val engine = Prefs.ENGINES[prefs.searchIndex].first
        addRow(R.drawable.ic_search, R.string.setting_search, engine, null) {
            val names = Prefs.ENGINES.map { it.first }.toTypedArray()
            AlertDialog.Builder(this)
                .setTitle(R.string.setting_search)
                .setSingleChoiceItems(names, prefs.searchIndex) { dialog, which ->
                    prefs.searchIndex = which
                    dialog.dismiss()
                    build()
                }
                .show()
        }

        addRow(R.drawable.ic_lock, R.string.setting_privacy, getString(R.string.setting_privacy_sub), null) {
            CookieManager.getInstance().removeAllCookies(null)
            WebStorage.getInstance().deleteAllData()
            prefs.clearHistory()
            Toast.makeText(this, R.string.data_cleared, Toast.LENGTH_SHORT).show()
        }

        addRow(R.drawable.ic_shield, R.string.setting_adblock, getString(R.string.setting_adblock_sub),
            prefs.adBlock) { checked -> prefs.adBlock = checked }

        addRow(R.drawable.ic_incognito, R.string.setting_private_info,
            getString(R.string.setting_private_info_sub), null) { }

        addRow(R.drawable.ic_download, R.string.setting_downloads, getString(R.string.setting_downloads_sub), null) {
            try {
                startActivity(android.content.Intent(android.app.DownloadManager.ACTION_VIEW_DOWNLOADS))
            } catch (e: Exception) {
                Toast.makeText(this, R.string.download_failed, Toast.LENGTH_SHORT).show()
            }
        }

        addRow(R.drawable.ic_desktop, R.string.setting_desktop, getString(R.string.setting_desktop_sub),
            prefs.desktopDefault) { checked -> prefs.desktopDefault = checked }

        addRow(R.drawable.ic_history, R.string.setting_gestures, getString(R.string.setting_gestures_sub),
            prefs.gestures) { checked -> prefs.gestures = checked }

        addRow(R.drawable.ic_star, R.string.setting_about, getString(R.string.setting_about_sub), null) { }
    }

    /** switchState null ise satır anahtarsızdır; onClick/onToggle satıra dokunulunca çalışır. */
    private fun addRow(
        icon: Int,
        title: Int,
        sub: String,
        switchState: Boolean?,
        action: (Boolean) -> Unit
    ) {
        val row = layoutInflater.inflate(R.layout.item_row, list as ViewGroup, false)
        row.findViewById<ImageView>(R.id.rowIcon).setImageResource(icon)
        row.findViewById<TextView>(R.id.rowTitle).setText(title)
        val subView = row.findViewById<TextView>(R.id.rowSub)
        subView.text = sub
        subView.visibility = View.VISIBLE
        val switch = row.findViewById<SwitchCompat>(R.id.rowSwitch)
        if (switchState != null) {
            switch.visibility = View.VISIBLE
            switch.isChecked = switchState
            row.setOnClickListener {
                switch.isChecked = !switch.isChecked
                action(switch.isChecked)
            }
        } else {
            row.setOnClickListener { action(false) }
        }
        list.addView(row)
    }
}
